package com.example.myfirstapp

import com.google.gson.annotations.SerializedName


data class MyFirstApp (

  @SerializedName("timestamp"        ) var timestamp        : String?                     = null,
  @SerializedName("sampling_rate"    ) var samplingRate     : String?                     = null,
  @SerializedName("id"               ) var id               : Int?                        = null,
  @SerializedName("sensordatavalues" ) var sensordatavalues : ArrayList<Sensordatavalues> = arrayListOf(),
  @SerializedName("sensor"           ) var sensor           : Sensor?                     = Sensor(),
  @SerializedName("location"         ) var location         : Location?                   = Location()

)