package com.example.myfirstapp

import com.google.gson.annotations.SerializedName


data class Sensordatavalues (

  @SerializedName("id"         ) var id        : Int?    = null,
  @SerializedName("value_type" ) var valueType : String? = null,
  @SerializedName("value"      ) var value     : String? = null

)